const preloader = document.querySelector(".loading-wrapper");

window.addEventListener('load' , () => {
    setTimeout(() => {
        preloader.style.display = 'none';
    }, 2000);
});