<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rasa Minang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="rmh gada.png" type="image/jpg">
</head>
<body>
    <style>
        #jadwal{
            background-color: #603C30;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        h1{
            font-family:Tahoma;
            color:#F5D6A5;
        }
        .card{
            background-color:#967546;
            font-family:Verdana;
            color:#F5D6A5;
            margin: 30px auto;
            width:500px;
        }
        #jadwal button{
            background-color:#DC9A2A;
            font-family:Helvetica;
            border:0;
            padding:14px 80px 14px 65px;
            background-repeat:no-repeat;
            cursor:pointer;
            font-weight:700;
            font-size:15px;
            border-radius: 50%;
            text-align: center;
        }
    </style>
    <div class="container-fluid" id="jadwal">
    <h1 class="text-center">Maaf warung sedang tutup!</h1>

                <div class="container">
                    <div class="card">
                    <div class="card-header">
                        <h2 class="text-center">Jam Operasional</h2>
                    </div>
                    <div class="card-body">
                    <p class="fw-bold fs-4">Senin-Jumat</p>
                    <p>10.00-22.00 WIB</p>
                    <p class="fw-bold fs-4">Sabtu-Minggu</p>
                    <p>Tutup</p>
                    </div>
                    </div>
                </div>


            <a href="index.php"><button><b>Back</b></button>
    </div>
        </center>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script> 
</body>
</html>