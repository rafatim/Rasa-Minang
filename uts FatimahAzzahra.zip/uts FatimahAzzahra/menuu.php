<!DOCTYPE html>
<html>
<head>
    <title>Rasa Minang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="rmh gada.png" type="image/jpg">
</head>
<body>
    <style>
.navbar{
    display:flex;
    align-items: center;
    justify-content: center;
    background-color:#603C30;
    box-shadow:0 5px 15px rgba(199, 121, 4, 0.432);
    z-index:999;
    position:sticky;
    top:0;
    left:0;
}

.navbar h4{
    font-family: Garamond;
    color: #f5d6a5;
    margin-left: 60px;
    padding-top: 9px;
}

.navbar li{
    padding:0 20px;
    position:relative;
}

.navbar li a{
    text-decoration: none;
    font-size: 16px;
    font-weight: 600;
    color: #f5d6a5;
    transition:0.30s ease;
}

.nav-uderline :hover,
.nav-uderline :active{
    color:#DC9A2A;
}

.navbar li a:hover,
.navbar li a:active{
    color:#DC9A2A;
}

#box{
background-color:#603C30;
display:flex;
flex-wrap:wrap;
justify-content:center;

}

#kotak{
background-color:#F5D6A5;
width:280px;
padding:10px;
margin:20px;

}

#kotak img{
width:260px;
height:280px;
}

#footer{
background-color:#603C30;
box-shadow: 0 5px 15px rgba(199, 121, 4, 0.432);
}

#footer p{
color:#DC9A2A;
}
</style>

<header class="sticky-top">
    <nav class="navbar">
    <div class="container-fluid">
      <a class="navbar-brand"><img src="rmh gada.png" style="float:left" width="50px"><h4><b><i>Rasa Minang</i></b></h4></a>
      <ul class="nav nav-underline justify-content-end">
        <li class="nav-item">
          <a class="nav-link " href="index.php">Home</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link active text-white" href="menuu.php">Menu</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="pesan.php">Contact</a>
        </li>
        </ul>
    </div>
    </nav>
    </header>

<div class="container-fluid p-2" style="background-color: #DC9A2A;" >
    <h3 class="text-center">Makanan</h3>
</div>

<?php
$menu_makanan = array(
    "ayam_bakar" => array("gambar" => "ayambakar.jpeg", "makan" => "Ayam Bakar", "harga" => 13000),
    "gulai_ayam" => array("gambar" => "gulai ayam.jpeg", "makan" => "Gulai Ayam", "harga" => 12000),
    "nasi" => array("gambar" => "nasi.jpeg", "makan" => "Nasi", "harga" => 5000),
    "dendeng" => array("gambar" => "dendeng.jpeg", "makan" => "Dendeng", "harga" => 20000),
    "rendang" => array("gambar" => "rendang.jpeg", "makan" => "Rendang", "harga" => 20000),
    "gulai_kikil" => array("gambar" => "gulai kikil.jpeg", "makan" => "Gulai Kikil", "harga" => 18000),
    "gulai_ikan" => array("gambar" => "ikan kakap.jpeg", "makan" => "Gulai Ikan", "harga" => 30000),
    "sate" => array("gambar" => "Sate Padang.jpeg", "makan" => "Sate", "harga" => 16000),
    "telor" => array("gambar" => "telor.jpeg", "makan" => "Telor Balado", "harga" => 8000),
    "dadar" => array("gambar" => "dadar.jpeg", "makan" => "Telor Dadar", "harga" => 6000),
    "perkedel" => array("gambar" => "perkedel.jpeg", "makan" => "Perkedel", "harga" => 6000),
    "nangka" => array("gambar" => "nangka.jpeg", "makan" => "Sayur Nangka", "harga" => 8000)
);

// Menampilkan menu makanan
echo "<div class='container-fluid' id='box'>";
foreach ($menu_makanan as $menu => $detail) {
    echo "<div class='row'>";
    echo "<div class='col-lg-3'>";
    echo "<div class='card' id='kotak'>";
    echo "<img src='" . $detail['gambar'] . "' alt='" . $detail['makan'] . "'>";
    echo "<h2>" . $detail['makan'] . "</h2>";
    echo "<p>Harga: Rp " . number_format($detail['harga'], 0, ',', '.') . "</p>";
    echo "</div>";
    echo "</div>";
    echo "</div>";

}
echo "</div>";
?>

<div class="container-fluid p-2" style="background-color: #DC9A2A;" >
    <h3 class="text-center">Minuman</h3>
</div>

<?php
$pilih_minuman = array(
    "teh" => array("poto" => "esteh.jpeg", "minum" => "Es Teh", "harga" => 5000),
    "jeruk" => array("poto" => "esjeruk.jpeg", "minum" => "Es Jeruk", "harga" => 8000),
    "teler" => array("poto" => "esteler.jpeg", "minum" => "Es Teler", "harga" => 12000)
);

// Menampilkan menu makanan
echo "<div class='container-fluid' id='box'>";
foreach ($pilih_minuman as $pilih => $aus) {
    echo "<div class='row'>";
    echo "<div class='col-lg-3'>";
    echo "<div class='card' id='kotak'>";
    echo "<img src='" . $aus['poto'] . "' alt='" . $aus['minum'] . "'>";
    echo "<h2>" . $aus['minum'] . "</h2>";
    echo "<p>Harga: Rp " . number_format($aus['harga'], 0, ',', '.') . "</p>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
}
echo "</div>";
?>

<footer>
    <div class="card text-center" id="footer">
    <div class="card-footer text-body-secondary" id="footer">
      <p>© Copyright <b>Rasa Minang</b>. All Rights Reserved</p>
    </div>
    </div>
</footer>
</body>
</html>
