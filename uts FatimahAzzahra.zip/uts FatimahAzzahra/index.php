<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rasa Minang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="rmh gada.png" type="image/jpg">
</head>
<body>
  <style>
        #spiner {
        background-color: #603C30;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100vh;
        z-index: 9999;
        display: flex;
        justify-content: center;
        align-items: center;
        transition: all 400ms ease-in-out;
    }
    
    .navbar {
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #603C30;
        box-shadow: 0 5px 15px rgba(199, 121, 4, 0.432);
        z-index: 999;
        position: sticky;
        top: 0;
        left: 0;
    }

    .navbar h4 {
        font-family: Garamond;
        color: #f5d6a5;
        margin-left: 60px;
        padding-top: 9px;
    }

    .navbar li {
        padding: 0 20px;
        position: relative;
    }

    .navbar li a {
        text-decoration: none;
        font-size: 16px;
        font-weight: 600;
        color: #f5d6a5;
        transition: 0.30s ease;
    }

    .nav-uderline :hover,
    .nav-uderline :active {
        color: #DC9A2A;
    }

    .navbar li a:hover,
    .navbar li a:active {
        color: #DC9A2A;
    }

    #hero{
        background-image:linear-gradient(rgba(92, 71, 14, 0.795),rgba(92, 71, 14, 0.795)), url(gadang.jpeg);
        height:90vh;
        width:100%;
        background-size:100%;
        background-position:top 25% right 0;
        padding:0 80px;
        display:flex;
        flex-direction:column;
        align-items: flex-start;
        justify-content: center;
    }
    
    #hero p{
        font-family:  Georgia;
        color: #fff7b3;
        padding-bottom:10px;
        font-size: 30px;
    }
    
    #hero h2{
      font-family: Pacifico;
        color:#FFF6D7;
        font-size:80px;
    }
    #ppp{
      background-color:#603C30;
      padding:30px;
    }
    #ppp h5{
      font-family: Baskerville;
      text-align:justify;
      padding:45px;
      color:#F5D6A5;
    }
    #ppp img{
      border-radius:3px;
      height:250px;
    }
    #footer{
      background-color:#603C30;
      box-shadow: 0 5px 15px rgba(199, 121, 4, 0.432);
    }
    #footer p{
      color:#DC9A2A;
    }
  </style>

  <div class="loading-wrapper" id="spiner">
    <div class="spinner-border me-2" style="width: 2rem; height: 2rem; color:#F5D6A5;" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
  </div>
    <script src="spiner.js"></script>
    
    <!--Header-->
    <header class="sticky-top">
    <nav class="navbar">
    <div class="container-fluid">
      <a class="navbar-brand"><img src="rmh gada.png" style="float:left" width="50px"><h4><b><i>Rasa Minang</i></b></h4></a>
      <ul class="nav nav-underline justify-content-end">
        <li class="nav-item">
          <a class="nav-link active text-white" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="menuu.php">Menu</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="pesan.php">Contact</a>
        </li>
        </ul>
    </div>
    </nav>
    </header>

    <div classs="container-fluid" id="hero">
    <?php
    $i="Rasa Minang";
    $j="Taklukkan lidahmu dengan kenikmatan Nusantara! Selamat datang di warung kami, di mana kehangatan bumbu bertemu dengan keramahan yang dapat memikat dan memuaskan di dunia rasa Nasi Padang kami.";

    echo "<h2>$i</h2>";
    echo "<p>$j</p>";
    ?>
    </div>

    <div class="container-fluid" id="ppp">
      <div class="row">
        <div class="col-lg-6">
          <?php
          $k="Rasa Minang adalah warung makan yang menawarkan hidangan khas Padang dengan cita rasa khas Minangkabau. Makanan Padang merupakan salah satu kebanggaan kuliner Indonesia yang terkenal dengan hidangan-hidangan yang kaya rempah dan bumbu, serta disajikan dalam porsi kecil di atas meja. Rasa Minang sendiri merujuk pada cita rasa khas dari daerah Minangkabau di Sumatera Barat, yang terkenal akan kelezatan masakannya.";

          echo "<h5 class='text'>$k</h5>";
          ?>
        </div>
        <div class="col-lg-6">
          <center>
          <img src="makanan.jpeg" width="500px" height="250px">
          </center>
        </div>
      </div>
    </div>

    <footer>
    <div class="card text-center" id="footer">
    <div class="card-footer text-body-secondary" id="footer">
      <p>© Copyright <b>Rasa Minang</b>. All Rights Reserved</p>
    </div>
    </div>
    </footer>
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script> 
</body>
</html>