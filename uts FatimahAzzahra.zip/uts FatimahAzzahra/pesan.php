<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rasa Minang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="rmh gada.png" type="image/jpg">
    <style>
    .navbar{
    display:flex;
    align-items: center;
    justify-content: center;
    background-color:#603C30;
    box-shadow:0 5px 15px rgba(199, 121, 4, 0.432);
    z-index:999;
    position:sticky;
    top:0;
    left:0;
    }

    .navbar h4{
        font-family: Garamond;
        color: #f5d6a5;
        margin-left: 60px;
        padding-top: 9px;
    }

    .navbar li{
        padding:0 20px;
        position:relative;
    }

    .navbar li a{
        text-decoration: none;
        font-size: 16px;
        font-weight: 600;
        color: #f5d6a5;
        transition:0.30s ease;
    }

    .nav-uderline :hover,
    .nav-uderline :active{
        color:#DC9A2A;
    }

    .navbar li a:hover,
    .navbar li a:active{
        color:#DC9A2A;
    }
        .container-fluid{
        background-color: #603C30;
        padding:20px;
        }
        #form{
        background-color:#DC9A2A;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        #footer{
        background-color:#603C30;
        box-shadow: 0 5px 15px rgba(199, 121, 4, 0.432);
        }

        #footer p{
        color:#DC9A2A;
        }
    </style>
</head>
<body>

<header class="sticky-top">
    <nav class="navbar">
    <div class="container-fluid">
      <a class="navbar-brand"><img src="rmh gada.png" style="float:left" width="50px"><h4><b><i>Rasa Minang</i></b></h4></a>
      <ul class="nav nav-underline justify-content-end">
        <li class="nav-item">
          <a class="nav-link " href="index.php">Home</a>
        </li>
        <li class="nav-item ">
          <a class="nav-link" href="menuu.php">Menu</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active text-white" href="pesan.php">Contact</a>
        </li>
        </ul>
    </div>
    </nav>
</header>

<?php
// Mendapatkan hari dan jam saat ini
date_default_timezone_set('Asia/Jakarta');
$hari_ini = date('l'); // Format l menghasilkan hari dalam bentuk teks
$jam_sekarang = date('H'); // Format H menghasilkan jam dalam format 24 jam

// Cek apakah hari ini adalah Senin-Jumat dan jamnya antara 10 pagi sampai 10 malam
if (($hari_ini == 'Monday' || $hari_ini == 'Tuesday' || $hari_ini == 'Wednesday' || $hari_ini == 'Thursday' || $hari_ini == 'Friday') && ($jam_sekarang >= 10 && $jam_sekarang < 22)) {
    // Jika iya, lanjutkan
    echo "";
} else {
    // Jika tidak, tampilkan pesan bahwa website sedang ditutup
    header("Location: jadwal.php");
}
?>

<div class="container-fluid">
<div class="container" id="form">
    <div class="text-center">
        <h3>Pemesanan</h3>
    </div>
    <div class="row">
        <div class="col-md-6">
            <form method="POST">
                
                <!-- Daftar pilihan makanan -->
                <div class="mb-3">
                    <?php
                    $menu_makanan = array(
                        "Ayam Bakar" => 13000,
                        "Gulai Ayam" => 12000,
                        "Nasi" => 5000,
                        "Dendeng" => 20000,
                        "Rendang" => 20000,
                        "Gulai Kikil" => 18000,
                        "Gulai Ikan" => 30000,
                        "Sate" => 16000,
                        "Telor Balado" => 8000,
                        "Telor Dadar" =>  6000,
                        "Perkedel" => 6000,
                        "Sayur Nangka" => 8000,
                        "Es Teh" => 5000,
                        "Es Jeruk" => 8000,
                        "Es Teler" => 12000
                    );
                    foreach ($menu_makanan as $menu => $harga) {
                        echo "<label class='form-label'>$menu - Rp $harga</label>";
                        echo "<input type='number' class='form-control' name='keranjang[$menu]' value='0' min='0'>";
                    }
                    ?>
                </div>
        </div>
        <div class="col-md-6">
        <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Nama :</label>
                    <input type="text" class="form-control" name="nama" id="nama" placeholder="Nama">
                </div>
            <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Alamat :</label>
                <textarea class="form-control" name="alamat" id="alamat" rows="6"></textarea>
            </div>

            <div class="mb-3">
                <label for="exampleFormControlTextarea1" class="form-label">Catatan :</label>
                <textarea class="form-control" name="catatan" id="catatan" rows="6"></textarea>
            </div>

            <button type="submit" class="btn btn-warning" name="submit">Pesan</button>
            </form>
        </div>
    </div>

<?php
// Logika untuk menangani input keranjang
if (isset($_POST['submit'])) {
    // Memeriksa apakah nama dan alamat diisi
    if (!empty($_POST['nama']) && !empty($_POST['alamat'])) {
        $nama = $_POST['nama'];
        $alamat = $_POST['alamat'];
        $catatan = isset($_POST['catatan']) ? $_POST['catatan'] : "";
        echo "<div class='card'>";
        echo "<div class='card-header'><h5 class='text-center'>Pesanan</h5></div>";
        echo "<div class='card-body'>";
        echo "<p>Nama : $nama</p>";
        echo "<p>Anda telah memilih menu berikut :</p>";
   
     
        // Iterasi menu makanan yang dipilih
        foreach ($_POST['keranjang'] as $menu => $jumlah) {
            if ($jumlah > 0) {
                // Tampilkan menu dan jumlah yang dipilih
                echo "<li>$menu - $jumlah</li>";
            }
        }

        // Menghitung total harga
   
        $total_harga = 0;
        foreach ($_POST['keranjang'] as $menu => $jumlah) {
            $total_harga += $menu_makanan[$menu] * $jumlah;
        }
        echo "<br>";
        echo "<p>Total harga : Rp $total_harga</p>";
        echo "<p>Alamat : $alamat</p>";
        echo "<p>Catatan : $catatan</p>";
    } else {
        // Jika nama atau alamat tidak diisi, tampilkan pesan kesalahan
        echo "<div class='alert alert-warning' role='alert'><p class='text-center'>Silakan lengkapi nama dan alamat Anda.</p></div>";
        echo "</center>";
    }
}
?>
</div>
</div>
</div>
</div>


<footer>
    <div class="card text-center" id="footer">
    <div class="card-footer text-body-secondary" id="footer">
      <p>© Copyright <b>Rasa Minang</b>. All Rights Reserved</p>
    </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
